#import <Cocoa/Cocoa.h>


@interface MyViewController : NSViewController
@end

