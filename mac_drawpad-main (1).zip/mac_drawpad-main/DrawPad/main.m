//
//  main.m
//  DrawPad
//
//  Created by numata on 2018/09/15.
//  Copyright (c) 2018年 numata. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
